"""
Tests for the ensemble pipeline: base learners combine into voting/stacking
ensembles that behave like proper scikit-learn classifiers.
"""

import numpy as np
import pandas as pd
from sklearn.ensemble import VotingClassifier, StackingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler


def _prepped(ensemble_module, raw_ilpd_csv):
    df = ensemble_module.load_data(raw_ilpd_csv)
    X, y = ensemble_module.preprocess(df)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.3, stratify=y, random_state=0
    )
    scaler = StandardScaler()
    X_train_s = pd.DataFrame(scaler.fit_transform(X_train), columns=X.columns)
    X_test_s = pd.DataFrame(scaler.transform(X_test), columns=X.columns)
    return X_train_s, X_test_s, y_train, y_test


def test_voting_classifier_trains_and_predicts(ensemble_module, raw_ilpd_csv):
    X_train, X_test, y_train, y_test = _prepped(ensemble_module, raw_ilpd_csv)

    base_learners = [
        ("logreg", LogisticRegression(max_iter=1000, random_state=0)),
        ("logreg2", LogisticRegression(max_iter=1000, C=10, random_state=0)),
    ]
    voting = VotingClassifier(estimators=base_learners, voting="soft")
    voting.fit(X_train, y_train)

    preds = voting.predict(X_test)
    proba = voting.predict_proba(X_test)
    assert len(preds) == len(y_test)
    assert proba.shape == (len(y_test), 2)
    assert np.allclose(proba.sum(axis=1), 1.0)


def test_evaluate_helper_handles_voting_classifier(ensemble_module, raw_ilpd_csv):
    X_train, X_test, y_train, y_test = _prepped(ensemble_module, raw_ilpd_csv)
    base_learners = [
        ("logreg", LogisticRegression(max_iter=1000, random_state=0)),
        ("logreg2", LogisticRegression(max_iter=1000, C=10, random_state=0)),
    ]
    voting = VotingClassifier(estimators=base_learners, voting="soft")
    voting.fit(X_train, y_train)

    metrics, y_pred, y_proba = ensemble_module.evaluate(voting, X_test, y_test)
    for key in ["Test Accuracy", "Test Precision", "Test Recall", "Test F1", "Test ROC-AUC"]:
        assert key in metrics
        assert 0.0 <= metrics[key] <= 1.0


def test_stacking_classifier_trains_and_predicts(ensemble_module, raw_ilpd_csv):
    X_train, X_test, y_train, y_test = _prepped(ensemble_module, raw_ilpd_csv)
    base_learners = [
        ("logreg", LogisticRegression(max_iter=1000, random_state=0)),
        ("logreg2", LogisticRegression(max_iter=1000, C=10, random_state=0)),
    ]
    stacking = StackingClassifier(
        estimators=base_learners,
        final_estimator=LogisticRegression(max_iter=1000, random_state=0),
        cv=3,
    )
    stacking.fit(X_train, y_train)
    preds = stacking.predict(X_test)
    assert len(preds) == len(y_test)
    assert set(np.unique(preds)) <= {0, 1}
