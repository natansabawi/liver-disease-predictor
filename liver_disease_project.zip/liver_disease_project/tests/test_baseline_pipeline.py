"""
Tests for the baseline pipeline's model factory and evaluation logic.
"""

import numpy as np
from sklearn.model_selection import StratifiedKFold, train_test_split


def test_get_models_returns_expected_families(baseline_module):
    models = baseline_module.get_models()
    expected = {
        "Logistic Regression", "Decision Tree", "Random Forest",
        "Gradient Boosting", "SVM (RBF)", "K-Nearest Neighbors", "Naive Bayes",
    }
    assert expected <= set(models.keys())


def test_get_models_all_support_predict_proba(baseline_module):
    """evaluate_model() relies on predict_proba to compute ROC-AUC; every
    registered model must support it or that metric silently goes missing."""
    models = baseline_module.get_models()
    for name, model in models.items():
        assert hasattr(model, "predict_proba"), f"{name} has no predict_proba"


def test_evaluate_model_returns_all_expected_metrics(baseline_module, raw_ilpd_csv):
    df = baseline_module.load_data(raw_ilpd_csv)
    X, y = baseline_module.preprocess(df)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.3, stratify=y, random_state=0
    )
    cv = StratifiedKFold(n_splits=3, shuffle=True, random_state=0)
    model = baseline_module.get_models()["Logistic Regression"]

    fitted, metrics, y_pred, y_proba = baseline_module.evaluate_model(
        "Logistic Regression", model, X_train, X_test, y_train, y_test, cv
    )

    expected_keys = {
        "Model", "CV ROC-AUC (mean)", "CV ROC-AUC (std)", "Test Accuracy",
        "Test Precision", "Test Recall", "Test F1", "Test ROC-AUC",
    }
    assert expected_keys <= set(metrics.keys())
    assert len(y_pred) == len(y_test)
    assert y_proba is None or len(y_proba) == len(y_test)


def test_evaluate_model_metrics_are_valid_probabilities(baseline_module, raw_ilpd_csv):
    """Accuracy/precision/recall/F1/ROC-AUC must all fall in [0, 1] -- a
    regression here usually means a label-encoding or metric-averaging bug."""
    df = baseline_module.load_data(raw_ilpd_csv)
    X, y = baseline_module.preprocess(df)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.3, stratify=y, random_state=0
    )
    cv = StratifiedKFold(n_splits=3, shuffle=True, random_state=0)
    model = baseline_module.get_models()["Random Forest"]

    _, metrics, _, _ = baseline_module.evaluate_model(
        "Random Forest", model, X_train, X_test, y_train, y_test, cv
    )
    for key in ["Test Accuracy", "Test Precision", "Test Recall", "Test F1", "Test ROC-AUC"]:
        assert 0.0 <= metrics[key] <= 1.0, f"{key}={metrics[key]} out of [0,1]"
