"""
Shared pytest fixtures and helpers.

The project's pipeline scripts (liver_disease_classification.py, etc.) are
written as standalone `python script.py` programs, not a package -- so tests
import them dynamically by file path rather than via a normal `import`.
Each script guards its training run behind `if __name__ == "__main__":`,
so importing it only defines functions/constants without executing the
full pipeline.
"""

import importlib.util
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

PROJECT_ROOT = Path(__file__).resolve().parent.parent


def import_script(filename):
    """Import one of the project's top-level scripts as a module by filename."""
    path = PROJECT_ROOT / filename
    module_name = filename.replace(".py", "").replace("-", "_")
    spec = importlib.util.spec_from_file_location(module_name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


@pytest.fixture(scope="session")
def baseline_module():
    return import_script("liver_disease_classification.py")


@pytest.fixture(scope="session")
def advanced_module():
    return import_script("liver_disease_classification_advanced.py")


@pytest.fixture(scope="session")
def ensemble_module():
    return import_script("liver_disease_ensemble.py")


@pytest.fixture(scope="session")
def predict_module():
    return import_script("predict_patient.py")


@pytest.fixture
def raw_ilpd_csv(tmp_path):
    """A small synthetic ILPD-shaped CSV (no header, 11 columns) for fast,
    hermetic unit tests that don't depend on the real 583-row dataset."""
    rng = np.random.default_rng(42)
    n = 40
    rows = []
    for i in range(n):
        gender = "Male" if i % 3 else "Female"
        label = 1 if i % 3 != 0 else 2  # roughly mimics class imbalance
        rows.append([
            rng.integers(4, 90),                      # Age
            gender,                                     # Gender
            round(rng.uniform(0.4, 10.0), 1),          # Total_Bilirubin
            round(rng.uniform(0.1, 5.0), 1),           # Direct_Bilirubin
            rng.integers(60, 500),                      # Alkaline_Phosphotase
            rng.integers(10, 150),                       # Alamine_Aminotransferase
            rng.integers(10, 150),                       # Aspartate_Aminotransferase
            round(rng.uniform(4.0, 9.0), 1),           # Total_Proteins
            round(rng.uniform(1.5, 5.5), 1),           # Albumin
            np.nan if i % 15 == 0 else round(rng.uniform(0.3, 2.0), 2),  # A/G Ratio (some NaNs)
            label,                                       # Dataset (target)
        ])
    df = pd.DataFrame(rows)
    path = tmp_path / "synthetic_ilpd.csv"
    df.to_csv(path, header=False, index=False)
    return path


@pytest.fixture
def real_data_path():
    path = PROJECT_ROOT / "data" / "indian_liver_patient.csv"
    if not path.exists():
        pytest.skip("real dataset not present at data/indian_liver_patient.csv")
    return path
