"""
Tests for the advanced pipeline: SMOTE balancing and the hyperparameter
search-space definitions.
"""

import pandas as pd
from imblearn.over_sampling import SMOTE
from sklearn.preprocessing import StandardScaler


def test_param_grids_cover_expected_models(advanced_module):
    assert set(advanced_module.PARAM_GRIDS.keys()) == {
        "Logistic Regression", "Random Forest", "SVM (RBF)"
    }


def test_param_grids_have_estimator_and_params(advanced_module):
    for name, cfg in advanced_module.PARAM_GRIDS.items():
        assert "estimator" in cfg and "params" in cfg
        assert isinstance(cfg["params"], dict) and len(cfg["params"]) > 0


def test_smote_balances_training_classes(advanced_module, raw_ilpd_csv):
    df = advanced_module.load_data(raw_ilpd_csv)
    X, y = advanced_module.preprocess(df)
    X_scaled = pd.DataFrame(StandardScaler().fit_transform(X), columns=X.columns)

    before_counts = y.value_counts()
    assert before_counts.min() != before_counts.max(), \
        "fixture should start imbalanced, or this test doesn't exercise SMOTE"

    X_res, y_res = SMOTE(random_state=0, k_neighbors=min(3, before_counts.min() - 1)).fit_resample(X_scaled, y)
    after_counts = pd.Series(y_res).value_counts()
    assert after_counts.min() == after_counts.max(), "SMOTE should equalize class counts"
    assert len(X_res) == len(y_res)


def test_evaluate_helper_matches_baseline_metric_keys(advanced_module, baseline_module, raw_ilpd_csv):
    """The advanced script's evaluate() should report the same core metrics
    as the baseline script's evaluate_model(), so comparison tables line up."""
    df = advanced_module.load_data(raw_ilpd_csv)
    X, y = advanced_module.preprocess(df)
    X_scaled = pd.DataFrame(StandardScaler().fit_transform(X), columns=X.columns)
    model = advanced_module.PARAM_GRIDS["Logistic Regression"]["estimator"]
    model.fit(X_scaled, y)

    metrics, y_pred, y_proba = advanced_module.evaluate(model, X_scaled, y)
    for key in ["Test Accuracy", "Test Precision", "Test Recall", "Test F1", "Test ROC-AUC"]:
        assert key in metrics
