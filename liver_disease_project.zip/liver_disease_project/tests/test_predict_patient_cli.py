"""
Tests for predict_patient.py's argument-collection logic, feature ordering,
and gender encoding -- the parts that are pure functions and don't require
loading the trained model.
"""

from types import SimpleNamespace

import pandas as pd
import pytest


def _full_args(**overrides):
    defaults = dict(
        age=45.0, gender="Male", total_bilirubin=1.2, direct_bilirubin=0.4,
        alkphos=200.0, alamine=30.0, aspartate=35.0, total_proteins=7.0,
        albumin=3.5, ag_ratio=1.0, fast=False,
    )
    defaults.update(overrides)
    return SimpleNamespace(**defaults)


def test_collect_from_args_returns_values_when_all_present(predict_module):
    args = _full_args()
    values = predict_module.collect_from_args(args)
    assert values is not None
    assert values["Age"] == 45.0
    assert values["Gender"] == "Male"
    assert values["Albumin_and_Globulin_Ratio"] == 1.0


def test_collect_from_args_returns_none_when_incomplete(predict_module):
    args = _full_args(age=None)
    assert predict_module.collect_from_args(args) is None


@pytest.mark.parametrize("raw,expected_code", [
    ("Male", 1), ("male", 1), ("Female", 0), ("female", 0),
])
def test_gender_encoding(raw, expected_code):
    """Mirrors the encoding logic inside predict_patient.main(): must match
    the LabelEncoder convention used during training (Female=0, Male=1),
    or predictions will be silently flipped."""
    gender_code = 1 if str(raw).lower() == "male" else 0
    assert gender_code == expected_code


def test_feature_names_match_training_schema(predict_module, ensemble_module):
    """The CLI's FEATURE_NAMES (order matters for a fitted scaler/model)
    must be exactly the training feature columns, minus the target."""
    training_columns = [c for c in ensemble_module.COLUMN_NAMES if c != "Dataset"]
    assert predict_module.FEATURE_NAMES == training_columns


def test_row_dataframe_has_correct_column_order(predict_module):
    values = predict_module.collect_from_args(_full_args())
    gender_code = 1 if str(values["Gender"]).lower() == "male" else 0
    row = {**values, "Gender": gender_code}
    X_new = pd.DataFrame([row])[predict_module.FEATURE_NAMES]
    assert list(X_new.columns) == predict_module.FEATURE_NAMES
    assert X_new.shape == (1, 10)
