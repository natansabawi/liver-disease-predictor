"""
Integration tests against the actual saved artifacts in outputs_ensemble/.
These skip cleanly if the artifacts haven't been generated yet (run
liver_disease_ensemble.py first) rather than failing the whole suite --
unit tests above cover the underlying logic independent of any saved file.
"""

from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import pytest

PROJECT_ROOT = Path(__file__).resolve().parent.parent
ENSEMBLE_DIR = PROJECT_ROOT / "outputs_ensemble"


def _require(*names):
    paths = [ENSEMBLE_DIR / n for n in names]
    if not all(p.exists() for p in paths):
        pytest.skip(f"artifacts not found in {ENSEMBLE_DIR} -- run liver_disease_ensemble.py first")
    return paths


def test_saved_model_and_scaler_load():
    model_path, scaler_path = _require("best_model_voting_ensemble.joblib", "scaler.joblib")
    model = joblib.load(model_path)
    scaler = joblib.load(scaler_path)
    assert hasattr(model, "predict_proba")
    assert hasattr(scaler, "transform")


def test_saved_model_predicts_valid_probability(predict_module):
    model_path, scaler_path = _require("best_model_voting_ensemble.joblib", "scaler.joblib")
    model = joblib.load(model_path)
    scaler = joblib.load(scaler_path)

    patient = pd.DataFrame([{
        "Age": 60, "Gender": 1, "Total_Bilirubin": 8.5, "Direct_Bilirubin": 4.2,
        "Alkaline_Phosphotase": 450, "Alamine_Aminotransferase": 90,
        "Aspartate_Aminotransferase": 110, "Total_Proteins": 6.0,
        "Albumin": 2.8, "Albumin_and_Globulin_Ratio": 0.6,
    }])[predict_module.FEATURE_NAMES]

    X_scaled = scaler.transform(patient)
    proba = model.predict_proba(X_scaled)[0, 1]
    assert 0.0 <= proba <= 1.0


def test_high_risk_labs_predict_higher_probability_than_normal_labs(predict_module):
    """A directional sanity check: a patient with clearly abnormal liver
    labs should score a higher disease probability than one with
    unremarkable labs. This would catch e.g. an inverted target label."""
    model_path, scaler_path = _require("best_model_voting_ensemble.joblib", "scaler.joblib")
    model = joblib.load(model_path)
    scaler = joblib.load(scaler_path)

    abnormal = pd.DataFrame([{
        "Age": 60, "Gender": 1, "Total_Bilirubin": 8.5, "Direct_Bilirubin": 4.2,
        "Alkaline_Phosphotase": 450, "Alamine_Aminotransferase": 90,
        "Aspartate_Aminotransferase": 110, "Total_Proteins": 6.0,
        "Albumin": 2.8, "Albumin_and_Globulin_Ratio": 0.6,
    }])[predict_module.FEATURE_NAMES]
    normal = pd.DataFrame([{
        "Age": 30, "Gender": 1, "Total_Bilirubin": 0.6, "Direct_Bilirubin": 0.15,
        "Alkaline_Phosphotase": 90, "Alamine_Aminotransferase": 18,
        "Aspartate_Aminotransferase": 20, "Total_Proteins": 7.2,
        "Albumin": 4.2, "Albumin_and_Globulin_Ratio": 1.4,
    }])[predict_module.FEATURE_NAMES]

    proba_abnormal = model.predict_proba(scaler.transform(abnormal))[0, 1]
    proba_normal = model.predict_proba(scaler.transform(normal))[0, 1]
    assert proba_abnormal > proba_normal


def test_shap_background_loads_and_matches_feature_count():
    (bg_path,) = _require("shap_background.joblib")
    background = joblib.load(bg_path)
    # shap.kmeans() result exposes .data as an (n_clusters, n_features) array
    data = getattr(background, "data", background)
    arr = np.asarray(data)
    assert arr.shape[1] == 10
