"""
Tests for data loading and preprocessing -- the foundation every downstream
script depends on. Run against a small synthetic CSV (fast, hermetic) so
these don't require the real dataset to be present.
"""

import numpy as np
import pandas as pd


def test_load_data_shape_and_columns(baseline_module, raw_ilpd_csv):
    df = baseline_module.load_data(raw_ilpd_csv)
    assert df.shape[1] == 11
    assert list(df.columns) == baseline_module.COLUMN_NAMES


def test_preprocess_no_missing_values_after_imputation(baseline_module, raw_ilpd_csv):
    df = baseline_module.load_data(raw_ilpd_csv)
    X, y = baseline_module.preprocess(df)
    assert X.isnull().sum().sum() == 0, "preprocess() must impute all missing values"


def test_preprocess_target_is_binary_0_1(baseline_module, raw_ilpd_csv):
    df = baseline_module.load_data(raw_ilpd_csv)
    _, y = baseline_module.preprocess(df)
    assert set(y.unique()) <= {0, 1}, "target must be remapped to {0, 1}"


def test_preprocess_gender_is_numeric(baseline_module, raw_ilpd_csv):
    df = baseline_module.load_data(raw_ilpd_csv)
    X, _ = baseline_module.preprocess(df)
    assert pd.api.types.is_numeric_dtype(X["Gender"])
    assert set(X["Gender"].unique()) <= {0, 1}


def test_preprocess_row_count_preserved(baseline_module, raw_ilpd_csv):
    """preprocess() must not silently drop rows (e.g. via naive dropna)."""
    df = baseline_module.load_data(raw_ilpd_csv)
    X, y = baseline_module.preprocess(df)
    assert len(X) == len(df)
    assert len(y) == len(df)


def test_preprocess_consistent_across_scripts(baseline_module, advanced_module, raw_ilpd_csv):
    """The baseline, advanced, and ensemble scripts each define their own
    preprocess() -- they must all agree, since the project's README assumes
    a single held-out split is comparable across every stage."""
    df1 = baseline_module.load_data(raw_ilpd_csv)
    df2 = advanced_module.load_data(raw_ilpd_csv)
    X1, y1 = baseline_module.preprocess(df1)
    X2, y2 = advanced_module.preprocess(df2)
    pd.testing.assert_frame_equal(X1, X2)
    pd.testing.assert_series_equal(y1, y2)


def test_real_dataset_matches_known_shape(baseline_module, real_data_path):
    """Sanity-check the real ILPD file hasn't been corrupted or truncated."""
    df = baseline_module.load_data(real_data_path)
    assert df.shape == (583, 11)
    assert df["Dataset"].isin([1, 2]).all()
    # Known class counts for the ILPD dataset
    counts = df["Dataset"].value_counts().to_dict()
    assert counts[1] == 416   # liver disease
    assert counts[2] == 167   # no disease
